#!/bin/bash
# Ubumatic 4 dla Ubuntu 10.04 Lucid Lynx LTS, 10.10 Maverick Meerkat i innych wersji
# Opis: Prosty skrypt do konfigurowania i zarządzania systemem
# Licencja: GPLv3
# Autor: empitt
# E-mail/XMPP: thempitt@gmail.com
##    Ubumatic 4
##    Copyright (C) 2010  Piotr Miros "empitt"
##
##    This program is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    This program is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with this program.  If not, see <http://www.gnu.org/licenses/>.
export ac=`uname -m`
export ce=`lsb_release -cs`
export er='Nie znaleziono:'
export hu='http://archive.ubuntu.com/ubuntu/'
export lt=()
export me='main restricted universe multiverse'
export um=/tmp/ubumatic
export u1=$um/ubumatic_1
export u2=$um/ubumatic_2
export u3=$um/ubumatic_3
if [ $ac = x86_64 ] ; then
	export ah='64 bitowe (x86_64)'
else
	export ah='32 bitowe (x86)'
fi
if [ $ce = lucid ] ; then
	export cn='10.04 Lucid Lynx LTS'
	export wh=532
else
	export cn='10.10 Maverick Meerkat'
	export wh=535
fi
function ad () { sudo -S add-apt-repository $* &> /dev/null ; }
function de () { rm -rf $um ; }
function pe () { zenity --width 500 --progress --title Ubumatic --text "$*. Proszę czekać...\n\nMoże to potrwać od kilku do kilkunastu minut" --pulsate --auto-close --percentage 15 ; }
function te () {
	killall "`basename $0`"
	exit 0
	}
function tu () { sed -n "/$*/p" $u1 ; }
function wg () {
	if [ $? = 1 ] ; then
		killall wget &> /dev/null
	fi
	}
function wt () { wget -q "`sed -n p $um/flashplayer.tar.gz`" -O $um/flashplayer.tar.gz &> /dev/null ; }
de
function b1 () {
	if [ ! -s /etc/apt/sources.list_backup ] ; then
		sudo cp -p /etc/apt/sources.list /etc/apt/sources.list_backup
	fi
	sudo bash -c "echo 'deb $hu $ce $me
deb-src $hu $ce $me
deb $hu $ce-updates $me
deb-src $hu $ce-updates $me
# deb $hu $ce-proposed $me
# deb-src $hu $ce-proposed $me
# deb $hu $ce-backports $me
# deb-src $hu $ce-backports $me
deb http://archive.canonical.com/ubuntu $ce partner
deb-src http://archive.canonical.com/ubuntu $ce partner
deb http://security.ubuntu.com/ubuntu $ce-security $me
deb-src http://security.ubuntu.com/ubuntu $ce-security $me
deb http://packages.medibuntu.org/ $ce free non-free
deb-src http://packages.medibuntu.org/ $ce free non-free
deb http://archive.getdeb.net/ubuntu $ce-getdeb apps games
deb-src http://archive.getdeb.net/ubuntu $ce-getdeb apps games' > /etc/apt/sources.list"
	if [ $ce = maverick ] ; then
		sudo sed -i "11i deb http://extras.ubuntu.com/ubuntu $ce main
			11i deb-src http://extras.ubuntu.com/ubuntu $ce main" /etc/apt/sources.list
	fi
	wget http://packages.medibuntu.org/medibuntu-key.gpg http://archive.getdeb.net/getdeb-archive.key -O - | sudo apt-key add -
	up
	echo sun-java6-jre shared/accepted-sun-dlj-v1-1 select true | sudo /usr/bin/debconf-set-selections
	il libavcodec-extra-52 libdvdcss2 p7zip-rar rar sun-java6-plugin ttf-mscorefonts-installer unrar
	if [ $ac = x86_64 ] ; then
		wget http://labs.adobe.com/downloads/flashplayer10_square.html -O /tmp/flashplayer.tar.gz
	else
		wget http://labs.adobe.com/downloads/flashplayer10.html -O /tmp/flashplayer.tar.gz
	fi
	sed -ni 's/.*\(http.\/\/download.macromedia.com\/pub\/labs\/flashplayer[0-9]\+\/flashplayer[0-9]\+.[0-9]\+.*[0-9]\+bit.linux.[0-9]\+.tar.gz\).*/\1/p' /tmp/flashplayer.tar.gz
	wget `sed -n p /tmp/flashplayer.tar.gz` -O /tmp/flashplayer.tar.gz
	tar xzf /tmp/flashplayer.tar.gz -C /tmp/ \
	&& sudo mkdir -p /usr/lib/flashplugin \
	&& sudo mv /tmp/libflashplayer.so /usr/lib/flashplugin/ \
	&& sudo ln -sf /usr/lib/flashplugin/libflashplayer.so /usr/lib/mozilla/plugins/
	rm -f /tmp/flashplayer.tar.gz
	}
function b2 () { il libmp4v2-0 ; }
function dk () { dpkg -l linux-image-2.6.*-generic | sed -n "/`uname -r`/d;s/^ii *[a-z-]\+\([0-9.]\+-[0-9]\+\).*/\1/p" ; }
function il () { sudo apt-get -y --force-yes install $* ; }
function qn () {
	while : ; do
		echo -ne '\033[1m(T)ak/(N)ie: \033[0m'
		read yn
		case $yn in
			t | T | tak | Tak | TAK )
				$*
				tn
			;;
			n | N | nie | Nie | NIE )
				clear
				exit 0
			;;
			* )
				continue
			;;
		esac
	done
	}
function rr () {
	z=0
	while [ $z -ne 2 ] ; do
		sudo dpkg -a --configure
		sudo apt-get -fy --force-yes install
		z=$(( $z + 1 ))
	done
	}
function tn () {
	clear
	echo -n 'Zakończono


Ubumatic 4 dla Ubuntu

Autor - empitt

E-mail/XMPP - thempitt@gmail.com'
	read
	clear
	exit 0
	}
function tt () {
	if [ `lsb_release -is` = Ubuntu ] ; then
		if [ "$ac" = "x86_64" -o "$ac" = "i686" ] ; then
			true
		else
			echo Skrypt nie obsługuje tej architektury procesora
			exit 0
		fi
	else
		echo Skrypt nie obsługuje tego systemu operacyjnego
		exit 0
	fi
	if [ $UID -ne 0 ] ; then
		echo 'Uruchom skrypt z prawami roota (sudo ./ubumatic.sh --opcja)'
		exit 0
	fi
	}
function up () {
	sudo apt-get update
	sudo apt-get -y --force-yes dist-upgrade
	}
function uu () {
	tt
	clear
	echo -e "\033[1mSkonfiguruj `lsb_release -ds` $ah\033[0m
Ustaw zalecane repozytorium, zainstaluj najnowsze aktualizacje, kodeki audio,
wideo, DVD itp., Flasha i otwartą Javę dla przeglądarek www, RAR-a i 7-Zipa
do kompresji i dekompresji plików oraz Windowsowe czcionki"
	}
if [ "$1" = "--help" ] ; then
		clear
		echo -ne 'Ubumatic 4 dla Ubuntu 10.04 Lucid Lynx LTS, 10.10 Maverick Meerkat i innych
wersji
Prosty skrypt do konfigurowania i zarządzania systemem
Dodatkowe opcje:
\t[./ubumatic.sh --help]
\t--help - pomoc
\t[sudo ./ubumatic.sh --opcja]
\t--clean - usuń zbędne pakiety, paczki i pliki konfiguracyjne
\t--deletekernel - usuń stare wersje kerneli
\t--emptytrash - opróżnij kosz ze wszystkich kont
\t--kubuntu - podstawowa konfiguracja Kubuntu (KDE)
\t--lubuntu - podstawowa konfiguracja Lubuntu (LXDE)
\t--repair - napraw uszkodzone pakiety
\t--repositories - edytuj repozytorium (sources.list), aktualizuj wpisy
\t  i pobierz brakujące klucze GPG
\t--restoregrub - zainstaluj ponownie program rozruchowy (tylko z Live CD)
\t--ubuntu - podstawowa konfiguracja Ubuntu (GNOME)
\t--upgrade - aktualizuj system
\t--xubuntu - podstawowa konfiguracja Xubuntu (Xfce)

UWAGA! Ze skryptu korzystasz na własną odpowiedzialność

Autor - empitt
E-mail/XMPP - thempitt@gmail.com'
		read
		clear
		exit 0
elif [ "$1" = "--clean" ] ; then
	function b3 () {
		sudo apt-get -y --purge autoremove
		dpkg -l | sed -n 's/^rc *\([^ ]\+\).*/\1/p' | xargs sudo dpkg -P
		sudo apt-get clean
		sudo rm -rf /home/*/.thumbnails/*/**
		sudo rm -rf /root/.thumbnails/*/**
	}
	tt
	clear
	echo -e '\033[1mUsuń zbędne pakiety, paczki i pliki konfiguracyjne\033[0m'
	qn b3
elif [ "$1" = "--deletekernel" ] ; then
	tt
	clear
	echo -e '\033[1mUsuń kernele:\033[0m'
	dk
	qn 'dk | xargs sudo apt-get -y --force-yes purge'
elif [ "$1" = "--emptytrash" ] ; then
	function b5 () {
		sudo rm -rf /home/*/.local/share/Trash/*/**
		sudo rm -rf /root/.local/share/Trash/*/**
	}
	tt
	clear
	echo -e '\033[1mOpróżnij kosz ze wszystkich kont\033[0m'
	qn b5
elif [ "$1" = "--kubuntu" ] ; then
	function b6 () {
		b1
		il kopete-gcall lame libdvdread4 libk3b6-extracodecs libmp3lame0 libtunepimp5-mp3 libxine1-ffmpeg
		rr
	}
	uu
	qn b6
elif [ "$1" = "--lubuntu" ] ; then
	function b7 () {
		b1
		b2
		il chromium-codecs-ffmpeg-extra
		rr
	}
	uu
	qn b7
elif [ "$1" = "--repair" ] ; then
	tt
	clear
	echo -e '\033[1mNapraw uszkodzone pakiety\033[0m'
	qn rr
elif [ "$1" = "--repositories" ] ; then
	function b4 () {
		sudo nano /etc/apt/sources.list
		y=0
		while [ $y -ne 2 ] ; do
			sudo apt-get update 2> $um
			sed -ni 's/.*NO_PUBKEY //gp' $um
			gpg --keyserver 'x-hkp://gpg-keyserver.de' --recv-keys `sed -n p $um`
			gpg --export --armor `sed -n p $um` | sudo apt-key add -
			y=$(( $y + 1 ))
		done
		de
	}
	tt
	clear
	echo -e '\033[1mEdytuj repozytorium, aktualizuj wpisy i pobierz brakujące klucze GPG\033[0m'
	qn b4
elif [ "$1" = "--restoregrub" ] ; then
	function bm () {
		if [ $? = 0 ] ; then
			break
		else
			continue
		fi
		}
	function m1 () { sudo mount "`sed -n '2s/\([^ ]\+\) [^ ]\+/\1/p' $um`" /mnt &> /dev/null ; }
	function m2 () { sudo mount "`sed -n '2s/[^ ]\+ \([^ ]\+\)/\1/p' $um`" /mnt/$* &> /dev/null ; }
	function nt () {
		zenity --question --title Ubumatic --text "$*\n\nCzy chcesz kontynuować?"
		if [ $? = 1 ] ; then
			de
			clear
			exit 0
		fi
		}
	function pn () { sudo fdisk -l | sed -n 's/\(\/dev\/[a-z]\+[0-9]\+\).*/\1/p' ; }
	function rd () { nt "· Montowanie:\n/\ - `sed -n "2s/\([^ ]\+\) \([^ ]\+\)/\1\n\/$* - \2/p" $um`\n· GRUB2:\n`tz 3`" ; }
	function ts () { sed -n "1s/$*/&/p" $um ; }
	function tz () { sed -n "$*"p $um ; }
	function u1 () { sudo umount /mnt/boot &> /dev/null ; }
	function u2 () { sudo umount /mnt/var &> /dev/null ; }
	function zy () { zenity --entry --title Ubumatic --text "Zamontuj / z Ubuntu, (spacja) /$* na partycjach:\n`pn`" --entry-text '/dev/sda1 /dev/sda2' >> $um ; }
	if [ ! -x /usr/bin/zenity ] ; then
		echo Nie znaleziono: /usr/bin/zenity
		exit 0
	fi
	tt
	zenity --question --title Ubumatic --ok-label Tak --cancel-label Nie --text 'Nie uruchamiaj przywracania GRUB-a na zainstalowanym\nUbuntu, ponieważ jest on przeznaczony dla Live CD\n\nCzy chcesz kontynuować?'
	if [ $? = 1 ] ; then
		exit 0
	fi
	clear
	echo Wykryto następujące dyski i partycje:
	sudo fdisk -l
	sleep 1
	bk=`zenity --width 373 --height 205 --list --title Ubumatic --text 'Ustaw punkty montowania' --hide-column 2 --radiolist --column '' --column '' --column 'Wybierz opcję' \
	TRUE 1 '/, /boot, /var na jednej partycji' \
	FALSE 2 '/, /var na jednej partcycji, /boot na oddzielnej' \
	FALSE 3 '/, /boot na jednej partcycji, /var na oddzielnej' \
	FALSE 4 '/, /boot, /var na oddzielnych partycjach'`
	case $bk in
		1 )
			echo 1 > $um
			while : ; do
				zenity --entry --title Ubumatic --text "Zamontuj / z Ubuntu na partycji:\n`pn`" --entry-text /dev/sda1 >> $um
				bm
			done
		;;
		2 )
			echo 2 > $um
			while : ; do
				zy boot
				bm
			done
		;;
		3 )
			echo 3 > $um
			while : ; do
				zy var
				bm
			done
		;;
		4 )
			echo 4 > $um
			while : ; do
				zenity --entry --title Ubumatic --text "Zamontuj / z Ubuntu, (spacja) /boot, (spacja) /var na partycjach:\n`pn`" --entry-text '/dev/sda1 /dev/sda2 /dev/sda3' >> $um
				bm
			done
		;;
		* )
			clear
			exit 0
		;;
	esac
	while : ; do
		zenity --entry --title Ubumatic --text "Zainstaluj program rozruchowy na:\n· dysku MBR (zalecane):\n`sudo fdisk -l | sed -n 's/[^ ]\+ \(\/dev\/[a-z]\+\).*/\1/p'`\n· lub partycji:\n`pn`" --entry-text /dev/sda >> $um
		bm
	done
	if [ `ts 1` ] ; then
		nt "· Montowanie:\n/\ - `tz 2`\n· GRUB2:\n`tz 3`"
	elif [ `ts 2` ] ; then
		rd boot
	elif [ `ts 3` ] ; then
		rd var
	elif [ `ts 4` ] ; then
		nt "· Montowanie:\n/\ - `sed -n '2s/\([^ ]\+\) \([^ ]\+\) \([^ ]\+\)/\1\n\/boot - \2\n\/var - \3/p' $um`\n· GRUB2:\n`tz 3`"
	fi
	(
	if [ `ts 1` ] ; then
		sudo mount "`tz 2`" /mnt &> /dev/null
	elif [ `ts 2` ] ; then
		m1
		m2 boot
	elif [ `ts 3` ] ; then
		m1
		m2 var
	elif [ `ts 4` ] ; then
		sudo mount "`sed -n '2s/\([^ ]\+\) [^ ]\+ [^ ]\+/\1/p' $um`" /mnt &> /dev/null
		sudo mount "`sed -n '2s/[^ ]\+ \([^ ]\+\) [^ ]\+/\1/p' $um`" /mnt/boot &> /dev/null
		sudo mount "`sed -n '2s/[^ ]\+ [^ ]\+ \([^ ]\+\)/\1/p' $um`" /mnt/var &> /dev/null
	fi
	sudo mount --bind /dev /mnt/dev &> /dev/null
	sudo mount --bind /proc /mnt/proc &> /dev/null
	sudo mount --bind /sys /mnt/sys &> /dev/null
	sudo chroot /mnt grub-install `tz 3` &> /dev/null
	sudo chroot /mnt update-grub &> /dev/null
	sudo umount /mnt/dev &> /dev/null
	sudo umount /mnt/proc &> /dev/null
	sudo umount /mnt/sys &> /dev/null
	if [ `ts 2` ] ; then
		u1
	elif [ `ts 3` ] ; then
		u2
	elif [ `ts 4` ] ; then
		u1
		u2
	fi
	sudo umount /mnt &> /dev/null
	) | while : ; do
		zenity --width 500 --progress --title Ubumatic --text 'Proszę czekać...\n\nMoże to potrwać kilka minut' --pulsate --auto-close --percentage 15
		bm
	done
	zenity --question --title Ubumatic --ok-label Tak --cancel-label Nie --text 'Zakończono\n\n\nUbumatic 4 dla Ubuntu\n\nAutor: empitt\n\nE-mail/XMPP: thempitt@gmail.com\n\n\nCzy chcesz ponownie uruchomić komputer?'
	if [ $? = 0 ] ; then
		sudo reboot
	else
		de
		clear
		exit 0
	fi
elif [ "$1" = "--ubuntu" -o "$1" = "--xubuntu" ] ; then
	function b8 () {
		b1
		b2
		il gstreamer0.10-ffmpeg gstreamer0.10-plugins-bad gstreamer0.10-plugins-bad-multiverse gstreamer0.10-plugins-ugly gstreamer0.10-plugins-ugly-multiverse
		if [ $ac = i686 ] ; then
			il gstreamer0.10-pitfdll
		fi
		if [ $ce = maverick ] ; then
			il gstreamer0.10-fluendo-mp3
		fi
		rr
	}
	uu
	qn b8
elif [ "$1" = "--upgrade" ] ; then
	tt
	clear
	echo -e '\033[1mZainstaluj najnowsze aktualizacje\033[0m'
	qn up
elif [ "$1" = "" ] ; then
	true
else
	echo Nie ma takiej opcji
	exit 0
fi
for tr in /usr/sbin/synaptic /usr/bin/zenity ; do
	if [ ! -x $tr ] ; then
		lt="${lt[@]} $tr"
	fi
done
if [ "`echo ${lt[@]}`" ] ; then
	if [ -x /usr/bin/zenity ] ; then
		zenity --error --title Ubumatic --text "$er ${lt[@]}"
	elif [ -x /usr/bin/kdialog ] ; then
		kdialog --title Ubumatic --error "$er ${lt[@]}"
	else
		echo $er ${lt[@]}
	fi
	exit 0
fi
if [ "$ce" = "lucid" -o "$ce" = "maverick" ] ; then
	if [ "$ac" = "x86_64" -o "$ac" = "i686" ] ; then
		true
	else
		zenity --error --title Ubumatic --text 'Skrypt nie obsługuje tej architektury procesora'
		exit 0
	fi
else
	zenity --error --title Ubumatic --text 'Skrypt nie obsługuje tego systemu operacyjnego'
	exit 0
fi
sudo -SK
zenity --entry --title Ubumatic --text 'Proszę podać swoje hasło' --hide-text | sudo -Su root true &> /dev/null
if [ $? = 1 ] ; then
	exit 0
fi
while : ; do
	sudo -Su root true &> /dev/null
	sleep 1m
done &
sudo -S fuser /var/lib/dpkg/lock &>/dev/null
if [ $? = 0 ] ; then
	zenity --error --title Ubumatic --text 'W tle pracuje inny menedżer pakietów'
	te
fi
st=`zenity --width $wh --height 343 --list --title 'Ubumatic 4' --text "Skonfiguruj Ubuntu $cn $ah" --hide-column 2 --checklist --column '' --column '' --column 'Zaznacz opcje' --separator : \
TRUE 1 'Ustaw zalecane repozytorium (obowiązkowe)' \
TRUE 2 'Zainstaluj najnowsze aktualizacje' \
FALSE 3 'Zainstaluj kodeki audio, wideo, DVD itp.' \
FALSE 4 'Zainstaluj Flasha i Javę dla przeglądarek www' \
FALSE 5 'Zainstaluj RAR-a i 7-Zipa do kompresji i dekompresji plików' \
FALSE 6 'Zainstaluj Windowsowe czcionki' \
FALSE 7 'Ustaw polskie napisy w odtwarzaczu filmów Totem' \
FALSE 8 'Zainstaluj oraz skonfiguruj odtwarzacz multimedialny MPlayer' \
FALSE 9 'Zainstaluj wtyczkę obsługującą Gadu-Gadu w komunikatorze Empathy' \
FALSE 10 'Zainstaluj Ubuntu Tweak do wygodnego zarządzania systemem'`
if [ $? = 0 ] ; then
	mkdir -p $um
	: > $u1 > $u2 > $u3
else
	te
fi
if [ -z $st ] ; then
	de
	te
fi
IFS=: ; for ar in $st ; do
	case $ar in
		1 )
			echo 1 >> $u1
			if [ $ce = maverick ] ; then
				echo 2 >> $u1
			fi
		;;
		2 )
			echo 3 >> $u1
		;;
		3 )
			echo 'libavcodec-extra-52 install
libdvdcss2 install
libmp4v2-0 install
gstreamer0.10-ffmpeg install
gstreamer0.10-plugins-bad install
gstreamer0.10-plugins-bad-multiverse install
gstreamer0.10-plugins-ugly install
gstreamer0.10-plugins-ugly-multiverse install' >> $u2
			if [ $ac = x86_64 ] ; then
				echo w64codecs install >> $u2
			else
				echo 'gstreamer0.10-pitfdll install
w32codecs install' >> $u2
			fi
			if [ $ce = maverick ] ; then
				echo gstreamer0.10-fluendo-mp3 install >> $u2
			fi
		;;
		4 )
			echo sun-java6-plugin install >> $u2
			if [ $ac = x86_64 ] ; then
				echo http://labs.adobe.com/downloads/flashplayer10_square.html > $um/flashplayer.tar.gz
			else
				echo http://labs.adobe.com/downloads/flashplayer10.html > $um/flashplayer.tar.gz
			fi
		;;
		5 )
			echo 'p7zip-rar install
rar install
unrar install' >> $u2
		;;
		6 )
			echo ttf-mscorefonts-installer install >> $u2
		;;
		7 )
			if [ -x /usr/bin/totem ] ; then
				gconftool-2 -t bool -s /apps/totem/autoload_subtitles true
				gconftool-2 -t str -s /apps/totem/subtitle_encoding WINDOWS-1250
			fi
		;;
		8 )
			if [ $ce = lucid ] ; then
				echo mplayer-gui install >> $u2
			else
				echo mplayer install >> $u2
			fi
			echo 4 >> $u1
		;;
		9 )
			if [ $ce = lucid ] ; then
				echo 5 >> $u1
			fi
			echo telepathy-sunshine install >> $u2
		;;
		10 )
			if [ $ce = lucid ] ; then
				echo 6 >> $u1
			fi
			echo ubuntu-tweak install >> $u2
		;;
	esac
done
if [ -s $u1 -o -s $u2 ] ; then
	( wget -q -t 5 -T 3 http://dl.dropbox.com/u/6294587/connection -O $u3 & ) | pe 'Trwa sprawdzanie połączenia z internetem'
	wg
	if [ ! -s $u3 ] ; then
		zenity --error --title Ubumatic --text 'Połączenie z internetem nie powiodło się'
		de
		te
	fi
fi
if [ "`tu 1`" -o "`tu 2`" -o "`tu 5`" -o "`tu 6`" ] ; then
	{ (
	if [ `tu 1` ] ; then
		if [ ! -s /etc/apt/sources.list_backup ] ; then
			sudo -S cp -p /etc/apt/sources.list /etc/apt/sources.list_backup
		fi
		sudo -S bash -c "echo 'deb $hu $ce $me
deb-src $hu $ce $me
deb $hu $ce-updates $me
deb-src $hu $ce-updates $me
# deb $hu $ce-proposed $me
# deb-src $hu $ce-proposed $me
# deb $hu $ce-backports $me
# deb-src $hu $ce-backports $me
deb http://archive.canonical.com/ubuntu $ce partner
deb-src http://archive.canonical.com/ubuntu $ce partner
deb http://security.ubuntu.com/ubuntu $ce-security $me
deb-src http://security.ubuntu.com/ubuntu $ce-security $me
deb http://packages.medibuntu.org/ $ce free non-free
deb-src http://packages.medibuntu.org/ $ce free non-free
deb http://archive.getdeb.net/ubuntu $ce-getdeb apps games
deb-src http://archive.getdeb.net/ubuntu $ce-getdeb apps games' > /etc/apt/sources.list"
		if [ `tu 2` ] ; then
			sudo -S sed -i "11i deb http://extras.ubuntu.com/ubuntu $ce main
				11i deb-src http://extras.ubuntu.com/ubuntu $ce main" /etc/apt/sources.list
		fi
		sudo -S apt-key adv --keyserver x-hkp://gpg-keyserver.de --recv-keys 2EBC26B60C5A2783 A8A515F046D7E7CF &> /dev/null
	fi
	if [ `tu 5` ] ; then
		ad ppa:kkszysiu/telepathy
	fi
	if [ `tu 6` ] ; then
		ad ppa:tualatrix/ppa
	fi
	) & } | pe 'Trwa konfigurowanie repozytorium'
	if [ $? = 1 ] ; then
		sudo -S killall add-apt-repository apt-key &> /dev/null
	fi
fi
if [ -s $u1 -o -s $u2 ] ; then
	sudo -S synaptic -t Ubumatic --hide-main-window --non-interactive --update-at-startup
fi
if [ `tu 3` ] ; then
	sudo -S synaptic -t Ubumatic --hide-main-window --non-interactive --dist-upgrade-mode
fi
if [ -s $u2 ] ; then
	zenity --warning --title Ubumatic --text 'Jeśli nie zaznaczyłeś opcji, która ustawia repozytorium, to\nwtedy nie wszystkie pakiety mogą zostać zainstalowane' --timeout 5
	sudo -S synaptic -t Ubumatic --hide-main-window --non-interactive --set-selections-file $u2
fi
if [ `tu 4` ] ; then
	if [ -x /usr/bin/mplayer ] ; then
		rm -rf $HOME/.mplayer
		mkdir $HOME/.mplayer
		echo 'font=/usr/share/fonts/truetype/freefont/FreeSans.ttf
subcp=cp1250' > $HOME/.mplayer/config
	fi
fi
if [ -s $um/flashplayer.tar.gz ] ; then
	{ (
	wt
	sed -ni 's/.*\(http.\/\/download.macromedia.com\/pub\/labs\/flashplayer[0-9]\+\/flashplayer[0-9]\+.[0-9]\+.*[0-9]\+bit.linux.[0-9]\+.tar.gz\).*/\1/p' $um/flashplayer.tar.gz &> /dev/null
	wt
	tar xzf $um/flashplayer.tar.gz -C $um/ &> /dev/null && : > $u3 || echo false > $u3 \
	&& sudo -S mkdir -p /usr/lib/flashplugin \
	&& sudo -S mv $um/libflashplayer.so /usr/lib/flashplugin/ \
	&& sudo -S ln -sf /usr/lib/flashplugin/libflashplayer.so /usr/lib/mozilla/plugins/
	) & } | pe 'Trwa pobieranie i instalowanie Flasha'
	wg
	if [ -s $u3 ] ; then
		zenity --error --title Ubumatic --text 'Instalacja Flasha nie powiodła się, ponieważ wyskoczyły błędy'
	fi
fi
if [ -s $u1 -o -s $u2 ] ; then
	(
	x=0
	while [ $x -ne 2 ] ; do
		sudo -S dpkg -a --configure &> /dev/null
		sudo -S apt-get -fy --force-yes install &> /dev/null
		x=$(( $x + 1 ))
	done
	) | while : ; do
		pe 'Trwa sprawdzanie i w razie czego naprawianie problemów'
		if [ $? = 0 ] ; then
			break
		else
			continue
		fi
	done
fi
de
zenity --info --title Ubumatic --text 'Zakończono\n\n\nUbumatic 4 dla Ubuntu 10.04 Lucid Lynx LTS\ni 10.10 Maverick Meerkat\n\nAutor: empitt\n\nE-mail/XMPP: thempitt@gmail.com'
te
